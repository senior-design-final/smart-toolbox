package recommender;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Collaborative filtering algorithm inside.
 */
public class Recommender {
  private static final int K = 8;  // k in the k-nearest neighbors algorithm
  private static final int NUM_TO_RECOMMEND = 4;  // max number of businesses to recommend

  /**
   * Recommends businesses to the user with id=userId
   */
  public List<Business> recommend(String userId) {
    System.out.println("User to investigate = " + BigData.getUserById(userId));
    System.out.println();

    PriorityQueue<Nearest> pqueue = new PriorityQueue<Nearest>(K);  // Stores top K nearest neighbors

    List<Review> userReviews = BigData.getUserReviews(userId);
    // helpful Map: user reviews sorted by business
    Map<String, Review> userReviewsByBusiness = new HashMap<String, Review>();
    for(Review review: userReviews) {
      userReviewsByBusiness.put(review.businessId, review);
    }

    // loop throw all users in the Big Data
    for(Map.Entry<String, List<Review>> anotherUserReviews: BigData.getReviewsByUsers()) {
      User anotherUser = BigData.getUserById(anotherUserReviews.getKey());
      if (!userId.equals(anotherUser.id)) {  // skip if it is the same user data
        if (hasSomethingToRecommend(userReviewsByBusiness, anotherUserReviews.getValue(), anotherUser.averageStars)) {
          Nearest n = new Nearest();
          n.similarity = calcCosineSimilarity(userReviewsByBusiness, anotherUserReviews.getValue());
          n.userId = anotherUser.id;
          pqueue.offer(n);  // inserts n to the priority queue
          if (pqueue.size() > K) {  // we should find only K neighbors
            pqueue.poll();  // remove least significant
          }
        }
      }
    }

    System.out.println("Most similar users found:");
    for(Nearest nearest: pqueue) {
      System.out.println(BigData.getUserById(nearest.userId) + " with similarity rating = " + nearest.similarity);
    }
    System.out.println();

    // find all recommended businesses by K neighbours
    List<Business> recommended = new ArrayList<Business>();
    for (Nearest nearest: pqueue) {
      User anotherUser = BigData.getUserById(nearest.userId);
      for (Review review: BigData.getUserReviews(nearest.userId)) {
        if (review.stars > anotherUser.averageStars) {   // only high ratings should be recommended
          if (!userReviewsByBusiness.containsKey(review.businessId)) {  // if is new business to target user
            Business recommendedBusiness = BigData.getBusinessById(review.businessId);
            recommended.add(recommendedBusiness);
          }
        }
      }
    }

    Collections.shuffle(recommended);  // Randomize recommendations
    recommended = recommended.subList(0, NUM_TO_RECOMMEND);  // We should return NUM_TO_RECOMMEND businesses

    System.out.println("Recommended businesses:");
    for(Business business: recommended) {
      System.out.println(business);
    }
    System.out.println();

    return recommended;
  }

  /**
   * Tests if other user has highly recommended business and first user know nothing about the business
   */
  private boolean hasSomethingToRecommend(Map<String, Review> user1ReviewsByBusiness, List<Review> user2Reviews, double user2AverageStars) {
    for (Review review: user2Reviews) {
      if (review.stars > user2AverageStars) {   // if review is higher than average of the user2
        if(!user1ReviewsByBusiness.containsKey(review.businessId)) {
          return true;  // found
        }
      }
    }
    return false;  // nothing found to recommend
  }

  /**
   * Returns cosine similarity of the reviews of two users.
   * The result is in the range [-1..1].
   * 1 indicates perfect similarity
   * -1 indicates perfect negative similarity
   */
  private double calcCosineSimilarity(Map<String, Review> user1ReviewsByBusiness, List<Review> user2Reviews) {
    double result = 0,
      xy = 0,  // numerator in cosine formula
      x2sum = 0,  // squared sum of x
      y2sum = 0;  // squared sum of y

    // calc part of denominator in cosine formula
    for(Review review: user1ReviewsByBusiness.values()) {
      x2sum += review.stars * review.stars;
    }

    // loop throw reviews of user2
    for(Review review2: user2Reviews) {
      if(user1ReviewsByBusiness.containsKey(review2.businessId)) {  // handle only business, which rated both users
        Review review1 = user1ReviewsByBusiness.get(review2.businessId);  // corresponding user1 review
        xy += review1.stars * review2.stars;
      }
      y2sum += review2.stars * review2.stars;
    }
    double denominator = (Math.sqrt(x2sum) * Math.sqrt(y2sum));  // denominator in cosine formula
    if (denominator > 0) {
      result = xy / denominator;
    }
    return result;
  }

  /**
   * Helper class. Entities stored in PriorityQueue to find K-Nearest Neighbor problem
   */
  private static class Nearest implements Comparable {
    public String userId;
    public double similarity;

    public int compareTo(Object o) {
      Nearest other = (Nearest)o;
      if(Math.abs(similarity - other.similarity) < 0.0001) {  // test floating point equality
        return 0;  // equal
      } else if(similarity > other.similarity) {
        return 1; // greater
      } else {
        return -1; // less
      }
    }
  }

}
