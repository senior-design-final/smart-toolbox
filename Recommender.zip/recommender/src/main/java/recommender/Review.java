package recommender;

import java.util.Date;

/**
 * Review data
 */
public class Review {
  public String businessId;
  public String userId;
  public long stars;
  public String date;
}
