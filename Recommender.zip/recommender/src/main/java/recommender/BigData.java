package recommender;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Contains large data set of businesses, users, reviews.
 */
public class BigData {

  private static Map<String, User> users = new HashMap();
  private static Map<String, List<Review>> reviewsByUser = new HashMap<String, List<Review>>();  // reviews grouped by user
  private static Map<String, Business> businesses  = new HashMap<String, Business>();

  private BigData() {
  }

  /**
   * Returns a list of reviews issued by user with id=userId
   */
  public static List<Review> getUserReviews(String userId) {
    return reviewsByUser.get(userId);
  }

  /**
   * Returns all reviews available
   */
  public static Set<Map.Entry<String, List<Review>>> getReviewsByUsers() {
    return reviewsByUser.entrySet();
  }

  /**
   * Returns business data of business with id=businessId
   */
  public static Business getBusinessById(String businessId) {
    return businesses.get(businessId);
  }

  /**
   * Returns user data of a user with id=userId
   */
  public static User getUserById(String userId) {
    return users.get(userId);
  }


  /**
   * Load data from disk located in folderPath
   */
  public static void load(String folderPath){
    try {
      System.out.println("Big data load started");
      loadBusinesses(folderPath);
      loadUsers(folderPath);
      loadReviews(folderPath);
      System.out.println("Big data load ended");
      System.out.println();
    } catch (Exception e) {
      throw new RuntimeException("Failed to load big data", e);
    }
  }

  /**
   * Load reviews
   */
  private static void loadReviews(String folderPath) throws Exception {
    JSONParser parser = new JSONParser();

    // open the file
    FileInputStream fstream = new FileInputStream(folderPath + "/yelp_academic_dataset_review.json");
    BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

    String line;
    // read File Line By Line
    while ((line = br.readLine()) != null) {
      JSONObject json = (JSONObject)parser.parse(line);

      // map json to Review
      Review review = new Review();
      review.businessId = (String)json.get("business_id");
      review.userId = (String)json.get("user_id");
      review.stars = (Long)json.get("stars");
      review.date = (String)json.get("date");

      // add review to collection, grouped by user
      if (!reviewsByUser.containsKey(review.userId)) {
        reviewsByUser.put(review.userId, new ArrayList<Review>());
      }
      reviewsByUser.get(review.userId).add(review);
    }

    // close the input stream
    br.close();

    System.out.println("Reviews loaded successfully");
  }

  private static void loadUsers(String folderPath) throws Exception {
    JSONParser parser = new JSONParser();
    for(String line: Files.readAllLines(Paths.get(folderPath + "/yelp_academic_dataset_user.json"))) {
      JSONObject json = (JSONObject)parser.parse(line);
      User user = new User();
      user.id = (String)json.get("user_id");
      user.averageStars = (Double)json.get("average_stars");
      user.reviewCount = (Long)json.get("review_count");
      user.name = (String)json.get("name");
      users.put((String)json.get("user_id"), user);
    }
    System.out.println("Users loaded successfully");
  }

  private static void loadBusinesses(String folderPath) throws Exception {
    JSONParser parser = new JSONParser();
    for(String line: Files.readAllLines(Paths.get(folderPath + "/yelp_academic_dataset_business.json"))) {
      JSONObject json = (JSONObject)parser.parse(line);
      Business business = new Business();
      business.id = (String)json.get("business_id");
      business.name = (String)json.get("name");
      business.address = (String)json.get("full_address");
      business.city = (String)json.get("city");
      business.state = (String)json.get("state");
      business.reviewCount = (Long)json.get("review_count");
      business.stars = (Double)json.get("stars");

      businesses.put(business.id, business);
    }
    System.out.println("Businesses loaded successfully");
  }
}
