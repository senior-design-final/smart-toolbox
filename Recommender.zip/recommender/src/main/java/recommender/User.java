package recommender;

/**
 * User data
 */
public class User {
  public String id;
  public String name;
  public long reviewCount;
  public double averageStars;

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("User {\n")
      .append("  name = ").append(name).append("\n")
      .append("  reviews count = ").append(reviewCount).append("\n")
      .append("  average stars = ").append(averageStars).append("\n")
      .append("  id = ").append(id).append("\n")
      .append("}");
    return sb.toString();
  }
}
