package recommender;

/**
 * Business data
 */
public class Business {
  public String id;
  public String address;
  public String name;
  public String city;
  public String state;
  public double stars;
  public long reviewCount;

  public String getAddress() {
    return address;
  }

  public String getName() {
    return name;
  }

  public String getCity() {
    return city;
  }

  public String getState() {
    return state;
  }

  public double getStars() {
    return stars;
  }

  public long getReviewCount() {
    return reviewCount;
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Business {\n")
      .append("  name = ").append(name).append("\n")
      .append("  city = ").append(city).append("\n")
      .append("  address = ").append(address).append("\n")
      .append("  rating = ").append(stars).append("\n")
      .append("  reviews count = ").append(reviewCount).append("\n")
      .append("  id = ").append(id).append("\n")
      .append("}");
    return sb.toString();
  }
}
