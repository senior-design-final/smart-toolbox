package recommender;

/**
 * Entry point of the console app
 */
public class ConsoleMain {
  public static void main(String args[]) throws Exception {
    if (args.length < 2) {
      System.out.println("No userId or data folder path provided. Exiting.");
      return;
    }
    BigData.load(args[1]);
    new Recommender().recommend(args[0]);
  }
}
