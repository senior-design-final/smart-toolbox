package recommender;

import org.apache.tomcat.InstanceManager;
import org.apache.tomcat.SimpleInstanceManager;
import org.eclipse.jetty.annotations.ServletContainerInitializersStarter;
import org.eclipse.jetty.apache.jsp.JettyJasperInitializer;
import org.eclipse.jetty.jsp.JettyJspServlet;
import org.eclipse.jetty.plus.annotation.ContainerInitializer;
import org.eclipse.jetty.server.ConnectionFactory;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.webapp.WebAppContext;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

/**
 * Entry point for a web-based application
 */
public class WebMain {

  public static void main(String args[]) throws Exception {
    if (args.length < 1) {
      System.out.println("No json data folder path provided. Exiting.");
      return;
    }
    BigData.load(args[0]);

    // configure and start Jetty
    Server server = new Server();
    ServerConnector connector = new ServerConnector(server);
    connector.setPort(8080);
    server.addConnector(connector);

    URI baseUri = WebMain.class.getResource("../web").toURI();

    WebAppContext context = new WebAppContext();
    context.setContextPath("/");
    context.setAttribute("org.eclipse.jetty.server.webapp.ContainerIncludeJarPattern",
      ".*/[^/]*servlet-api-[^/]*\\.jar$|.*/javax.servlet.jsp.jstl-.*\\.jar$|.*/.*taglibs.*\\.jar$");
    context.setResourceBase(baseUri.toASCIIString());
    context.setAttribute("org.eclipse.jetty.containerInitializers", jspInitializers());
    context.setAttribute(InstanceManager.class.getName(), new SimpleInstanceManager());
    context.addBean(new ServletContainerInitializersStarter(context), true);
    context.setClassLoader(new URLClassLoader(new URL[0], WebMain.class.getClassLoader()));

    context.addServlet(new ServletHolder("jsp", JettyJspServlet.class), "*.jsp");

    server.setHandler(context);

    // Start Server
    server.start();
    server.join();
  }



  /**
   * Ensure the jsp engine is initialized correctly
   */
  private static List<ContainerInitializer> jspInitializers()
  {
    JettyJasperInitializer sci = new JettyJasperInitializer();
    ContainerInitializer initializer = new ContainerInitializer(sci, null);
    List<ContainerInitializer> initializers = new ArrayList<ContainerInitializer>();
    initializers.add(initializer);
    return initializers;
  }

}
